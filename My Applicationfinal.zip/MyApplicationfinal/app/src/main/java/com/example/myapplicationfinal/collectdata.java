package com.example.myapplicationfinal;

public class collectdata {
    String foodName,foodQuantity,address;


    public String getFoodName() {
        return foodName;
    }

    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }

    public String getFoodQuantity() {
        return foodQuantity;
    }

    public void setFoodQuantity(String foodQuantity) {
        this.foodQuantity = foodQuantity;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public collectdata(String foodName, String foodQuantity, String address) {
        this.foodName = foodName;
        this.foodQuantity = foodQuantity;
        this.address = address;

    }
}
