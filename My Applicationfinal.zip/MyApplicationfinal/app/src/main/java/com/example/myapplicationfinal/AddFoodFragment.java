package com.example.myapplicationfinal;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AddFoodFragment extends Fragment {

    EditText text1, text2, text3, text4;
    Button button1;
    View view;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_add_food, container, false);
        button1 = view.findViewById(R.id.btn1ID);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Add your button click logic here
                text1=getView().findViewById(R.id.text1);
                text2=getView().findViewById(R.id.text2);
                text3=getView().findViewById(R.id.text3);
                text4=getView().findViewById(R.id.text4);

                String foodID = text1.getText().toString().trim();
                String foodName = text2.getText().toString().trim();
                String foodQuantity = text3.getText().toString().trim();
                String foodPrice = text4.getText().toString().trim();

                collectdata collect = new collectdata(foodName,foodQuantity,foodPrice);

                FirebaseDatabase db = FirebaseDatabase.getInstance();
                DatabaseReference root = db.getReference("Food");
                root.child(foodID).setValue(collect);

                text1.setText("");
                text2.setText("");
                text3.setText("");
                text4.setText("");

                Toast.makeText(getContext(), "Data Inserted", Toast.LENGTH_SHORT).show();
            }
        });
        return view;
    }
}









