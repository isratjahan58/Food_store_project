package com.example.myapplicationfinal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class CalculatorActivity extends AppCompatActivity {
    TextView primaryView,secondaryView;
    Button tempButton;
    String operator ,firstNumber,secondNumber ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator);
        primaryView=findViewById((R.id.primaryTextViewID));
        secondaryView =findViewById(R.id.secondaryTextViewID);
    }
    public void numericFunction(View view) {
        tempButton =findViewById(view.getId());
        if (primaryView.getText().toString().equals("0") ) {
            primaryView.setText(tempButton.getText().toString());

        }
        else {
            primaryView.setText(primaryView.getText().toString()+tempButton.getText().toString());
        }

    }
    public void clearFunction(View view){
        primaryView.setText("0");
        secondaryView.setText("");
        firstNumber="";
        secondNumber="";
        operator="";
    }

    public void operatorFunction(View view) {
        tempButton=findViewById(view.getId());
        operator=tempButton.getText().toString();
        firstNumber =primaryView.getText().toString();
        secondaryView.setText( firstNumber+" "+operator);
        primaryView.setText("0");
    }

    public void resultFunction(View view) {
        secondNumber =primaryView.getText().toString();
        double result = 0;
        if(operator.equals("+")){
            result =Double.parseDouble(firstNumber)+Double.parseDouble(secondNumber);

        }
        else if(operator.equals("-")){
            result =Double.parseDouble(firstNumber)-Double.parseDouble(secondNumber);

        } else if(operator.equals("*")){
            result =Double.parseDouble(firstNumber)*Double.parseDouble(secondNumber);

        }

        secondaryView.setText(firstNumber+ " " +operator+ " "+secondNumber+" ");
        primaryView.setText(""+result);

    }
}
