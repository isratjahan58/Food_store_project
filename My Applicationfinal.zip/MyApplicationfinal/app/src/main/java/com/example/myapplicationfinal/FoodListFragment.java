package com.example.myapplicationfinal;

import android.content.Intent;
import android.os.Bundle;
import com.google.firebase.database.ValueEventListener;
import androidx.fragment.app.Fragment;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.ArrayList;
import java.util.List;
import android.widget.Toast;

public class FoodListFragment extends Fragment {

    View view;
    private ListView listViewFood;
    private ArrayAdapter<String> adapter;
    private List<String> foodList;
    private DatabaseReference databaseReference;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_food_list, container, false);
        listViewFood = view.findViewById(R.id.listViewFood);

        // Initialize the employee list and adapter
        foodList = new ArrayList<>();
        adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_list_item_1, foodList);
        listViewFood.setAdapter(adapter);

        // Get a reference to the Firebase Realtime Database
        databaseReference = FirebaseDatabase.getInstance().getReference().child("Food");

        // Read data from the database
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot childSnapshot : dataSnapshot.getChildren()) {
                    String foodName = childSnapshot.child("foodName").getValue(String.class);
                    String foodQuantity = childSnapshot.child("foodQuantity").getValue(String.class);
                    String address = childSnapshot.child("address").getValue(String.class);

                    String foodDetails = "Food Name: " + foodName + "\nFood Quantity: " + foodQuantity + "\naddress: " + address;

                    foodList.add(foodDetails);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle database error
            }
        });
        return view;

    }
}







